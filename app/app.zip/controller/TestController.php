<?php

declare(strict_types=1);

namespace app\controller;

use think\facade\Log;
use think\Request;

class TestController
{
    public function index(Request $request)
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST');
        header('Access-Control-Allow-Headers: Authorization, Content-Type, If-Match, If-Modified-Since, If-None-Match, If-Unmodified-Since, X-Requested-With');
        header('Access-Control-Allow-Credentials: true');
        Log::write($request->param());
        return '测试控制器';
    }
    public function test(Request $request)
    {
        $sid = 'ckaWEjwF5IPj';
        $curlParams = [
            'appid' => 'wx5b97b0686831c076',
            'path' => 'pages/navigate/navigate',
            'query' => http_build_query([
                'url' => 'pages/preview/preview?from=wxminiprogram&fid=256465035925&sid=' . $sid . '&fname=' . urlencode('扫码加微信.docx'),
                'scene' => '102',
                'jump_from' => 'wechatlogin_guide_passive',
                'comp' => 'docx',
                'dw' => '1',
            ]),
            'env_version' => 'release',
            'is_expire' => 'true',
            'expire_time' => time() + 7200,
        ];

        return http_build_query($curlParams);
    }
    public function test2(Request $request)
    {
        $userID = 'o3Ueb5';
        $cliID = 'qb09ECO';
        $url = "https://nc.cli.im/api/weixin/getWxUrlScheme/?query=q=qr61.cn/{$userID}/{$cliID}&path=pages/code/code&appid=wx5db79bd23a923e8e&org_coding={$userID}";

        return $url;
    }
    public function test3(Request $request)
    {
        $iv = openssl_random_pseudo_bytes(16);
        $key = openssl_encrypt('12345678', 'AES-128-CBC', '4ed10aaff8e2eb5619e7ce447c7f8f6b');
        return $key;
    }
}
