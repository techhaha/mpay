<?php

declare(strict_types=1);

namespace payclient;

class FuBei
{
    // 收款平台
    private $pay_type = 'fubei';
    // 收款平台账号
    private $username;
    // 平台登陆密码
    private $password;
    // token保存路径
    private $token_path;
    // Cookie保存路径
    private $cookie_path;
    // 当前时间戳
    private $now;
    // 收款平台网站
    private $payhost = 'https://e.51fubei.com';
    // 登陆Cookie
    private $setcookie_path = '/Index/Login/index';
    // 用户登陆接口
    private $login_path = '/Login/handle';
    // 订单查询接口
    private $order_query_path = '/User/NewFundManagement/tradestats';

    function __construct(array $config)
    {
        $this->username = $config['username'];
        $this->password = md5($config['password']);
        $this->now = time();
        // 检查token/cookie目录
        $dir_path = runtime_path() . "token/{$this->pay_type}/";
        if (!is_dir($dir_path)) {
            if (!mkdir($dir_path, 755, true)) echo '创建token/cookie目录失败';
        }
        // token/cookie文件路径
        $this->token_path = $dir_path . md5($this->username . $this->password . __CLASS__) . '.json';
        $this->cookie_path = $dir_path . md5($this->username . $this->password . __CLASS__) . '.txt';
        // 检查token文件
        if (!file_exists($this->token_path)) {
            file_put_contents($this->token_path, json_encode(['token' => 'ok', 'update_time' => date('Y-m-d H:i:s')]));
        }
    }
    // 获取订单信息
    public function getOrderInfo(array $query): array
    {
        $order_list = $this->queryOrder($query);
        $orders = [];
        if (!$order_list) return $orders;
        $payways = [2 => 'alipay', 1 => 'wxpay'];
        foreach ($order_list as $value) {
            $order = [];
            // 平台订单流水号
            $order['order_no'] = $value['order_sn'];
            // 支付类型
            $payway = $value['pay_type'];
            $order['payway'] = isset($payways[$payway]) ? $payways[$payway] : 'otherpay';
            // 收款金额
            $order['price'] = (float)($value['order_sumprice']);
            // 收款渠道(二维码编号)
            $order['channel'] = $value['device_no'] === '' || $value['device_no'] === null ? $value['store_id'] : $value['device_no'];
            // 添加到订单列表
            $orders[] = $order;
        }
        return $orders;
    }
    // 查询订单
    private function queryOrder(array $query, $times = 0): array
    {
        // 查询订单列表
        $url = $this->payhost . $this->order_query_path;
        $header = ['Content-Type: application/x-www-form-urlencoded', 'Origin:https://e.51fubei.com', 'Referer:https://e.51fubei.com/User/NewFundManagement/tradestats', 'X-Requested-With:XMLHttpRequest'];
        $new_query = $this->getOrderQuery($query);
        $res = $this->getHttpResponse($url, $header, http_build_query($new_query));
        $result = json_decode($res, true);
        // 检查订单信息
        $order_list = [];
        if ($result['status'] === 'ok') {
            $order_list = $result['data'];
        } else {
            // 重试1次
            if ($times < 1) {
                $this->updateToken();
                $order_list = $this->queryOrder($query, $times + 1);
            }
        }
        return $order_list;
    }
    // 构建订单查询数组信息
    private function getOrderQuery(array $query): array
    {
        $new_query = $query;
        $now = $this->now;
        $begin_time = date('Y-m-d H:i:s', $now - 175);
        $end_time = date('Y-m-d H:i:s', $now);
        $new_query['start_time'] = $begin_time;
        $new_query['end_time'] = $end_time;
        return $new_query;
    }
    // 登陆账号
    private function login($times = 0): bool
    {
        $this->getHttpResponse($this->payhost . $this->setcookie_path);
        $url = $this->payhost . $this->login_path;
        $user_info = [
            "username" => $this->username,
            "password" => $this->password,
            'latitude' => '',
            'longitude' => '',
            'isAgree' => 1,
            'verifyCode' => '',
            'isOem' => 2,
            'isStopLogin' => 1,
        ];
        $header = ['Content-Type: application/x-www-form-urlencoded', 'Origin:https://e.51fubei.com', 'Referer:https://e.51fubei.com/Index/Login/index', 'X-Requested-With:XMLHttpRequest'];
        $res = $this->getHttpResponse($url, $header, http_build_query($user_info));
        $data = json_decode($res, true);
        if ($data['status'] === 1) {
            // 保存token
            return true;
        } else {
            // 重试1次
            $is_login = false;
            if ($times < 1) {
                $is_login = $this->login($times + 1);
                return $is_login;
            }
            return $is_login;
        }
    }
    // 更新token
    private function updateToken(): bool
    {
        $is_login = $this->login();
        return $is_login;
    }
    // 获取token
    private function getToken(): string
    {
        $token_info = json_decode(file_get_contents($this->token_path), true);
        return $token_info['token'];
    }
    // 保存token
    private function saveToken($data)
    {
        $token = $data['token'];
        file_put_contents($this->token_path, json_encode(['token' => $token, 'update_time' => date('Y-m-d H:i:s')]));
    }
    // 请求外部资源
    private function getHttpResponse($url, $header = [], $post = null, $timeout = 10)
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_COOKIEJAR, $this->cookie_path);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $this->cookie_path);
        if ($header) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        } else {
            $httpheader[] = "Accept: */*";
            $httpheader[] = "Accept-Language: zh-CN,zh;q=0.9";
            $httpheader[] = "Connection: close";
            curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
        }
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        if ($post) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }
}
