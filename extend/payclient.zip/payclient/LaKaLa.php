<?php

declare(strict_types=1);

namespace payclient;

class LaKaLa
{
    // 收款平台
    private $pay_type = 'lklpay';
    // 收款平台账号
    private $username;
    // 平台登陆密码
    private $password;
    // token保存路径
    private $token_path;
    // Cookie保存路径
    private $cookie_path;
    // 当前时间戳
    private $now;
    // 收款平台网站
    private $payhost = 'https://m2.lakala.com';
    // 用户登陆接口
    private $login_path = '/m/lamsmerdash/account/pwdLogin';
    // 订单查询接口
    private $order_query_path = '/m/a/lamsmerdash/merTrans/new/queryTranInfoList';
    // 验证码接口
    private $captcha_path = '/m/lamsmerdash/slider/get';
    // 查询默认用户
    private $getuser = '/m/a/mp3Ms/userIdentity/queryDefaultIdentityAndMer';
    // 设置当前用户
    private $setuser = '/m/a/mp3Ms/userIdentity/changeIdentityAndMer';

    function __construct(array $config)
    {
        $this->username = $config['username'];
        $this->password = $config['password'];
        $this->now = time();
        // 检查token/cookie目录
        $dir_path = runtime_path() . "token/{$this->pay_type}/";
        if (!is_dir($dir_path)) {
            if (!mkdir($dir_path, 755, true)) echo '创建token/cookie目录失败';
        }
        // token/cookie文件路径
        $this->token_path = $dir_path . md5($this->username . $this->password . __CLASS__) . '.json';
        $this->cookie_path = $dir_path . md5($this->username . $this->password . __CLASS__) . '.txt';
        // 检查token文件
        if (!file_exists($this->token_path)) {
            file_put_contents($this->token_path, json_encode(['token' => 'ok', 'update_time' => date('Y-m-d H:i:s'), "merInnerNo" => 'ok', "merchantNo" => 'ok']));
        }
    }
    // 获取订单信息
    public function getOrderInfo(array $query): array
    {
        $order_list = $this->queryOrder($query);
        $orders = [];
        if (!$order_list) return $orders;
        $payways = ['ALI' => 'alipay', 'WECHAT' => 'wxpay', 'UNION_D' => 'unionpay', 'UNION_C' => 'unionpay'];
        foreach ($order_list as $value) {
            $order = [];
            // 平台订单流水号
            $order['order_no'] = $value['tranAcpBsNo'];
            // 支付类型
            $payway = $value['tranChannelType'];
            $order['payway'] = isset($payways[$payway]) ? $payways[$payway] : 'otherpay';
            // 收款金额
            $order['price'] = (float)$value['tranOrdAmt'];
            // 收款渠道(二维码编号)
            $order['channel'] = $value['bsShopCode'];
            // 添加到订单列表
            $orders[] = $order;
        }
        return $orders;
    }
    // 查询订单
    private function queryOrder(array $query, $times = 0): array
    {
        // 查询订单列表
        $url = $this->payhost . $this->order_query_path;
        $userinfo = $this->getToken();
        $var_query = ["openEntity" => $userinfo['merchantNo'], "merchantNos" => $userinfo['merchantNo']];
        $token = $userinfo['token'];
        $header = ['host:m2.lakala.com', 'content-type:application/json', 'origin:https://customer.lakala.com', 'referer:https://customer.lakala.com/', "authorization:{$token}"];
        $query = array_merge($query, $var_query);
        $new_query = $this->getOrderQuery($query);
        $res = $this->getHttpResponse($url, $header, json_encode($new_query));
        $result = json_decode($res, true);
        // 检查订单信息
        $order_list = [];
        if ($result['code'] === '000000') {
            $order_list = $result['data'];
        } else {
            // 重试1次
            if ($times < 1) {
                $this->updateToken();
                $order_list = $this->queryOrder($query, $times + 1);
            }
        }
        return $order_list;
    }
    // 构建订单查询数组信息
    private function getOrderQuery(array $query): array
    {
        $new_query = $query;
        $now = $this->now;
        $new_query['startDate'] = date('Ymd', $now - 175);
        $new_query['startTime'] = date('His', $now - 175);
        $new_query['endDate'] = date('Ymd', $now);
        $new_query['endTime'] = date('His', $now);
        $new_query['requestTime'] = date('YmdHis', $now);
        $new_query['requestId'] = date('YmdHis', $now) . mt_rand(100000, 999999);
        return $new_query;
    }
    // 获取验证码图像
    private function getCaptcha(): array
    {
        $url = $this->payhost . $this->captcha_path;
        $header = ['host:m2.lakala.com', 'content-type:application/json', 'origin:https://customer.lakala.com', 'referer:https://customer.lakala.com/'];
        $info = ["requestId" => date('YmdHis') . mt_rand(100000, 999999), "requestTime" => date('YmdHis'), "systemCode" => "MERDASH", "version" => "1.0"];
        $res = $this->getHttpResponse($url, $header, json_encode($info));
        $data = json_decode($res, true);
        $captcha_info = [];
        if ($data['code'] === '000000') {
            $captcha_info['requestId'] = $info['requestId'];
            $captcha_info['requestTime'] = $info['requestTime'];
            $captcha_info['data'] = $data['data'];
        }
        return $captcha_info;
    }
    // 登陆账号
    private function login(int $times = 0): bool
    {
        $captcha_info = $this->getCaptcha();
        $captcha = $this->getCaptchaInfo($captcha_info['data']['original'], '33');
        $url = $this->payhost . $this->login_path;
        $user_info = [
            "requestTime" => $captcha_info['requestTime'],
            "systemCode" => "MERDASH",
            "version" => "1.0",
            "requestId" => $captcha_info['requestId'],
            "sliderReq" => ["x" => $captcha, "y" => $captcha_info['data']['y'], "token" => $captcha_info['data']['token']],
            "account" => $this->username,
            "pwd" => $this->password,
        ];
        $header = ['host:m2.lakala.com', 'content-type:application/json', 'origin:https://customer.lakala.com', 'referer:https://customer.lakala.com/'];
        $res = $this->getHttpResponse($url, $header, json_encode($user_info));
        $data = json_decode($res, true);
        if ($data['code'] === '000000') {
            $token = $data['data']['authorization'];
            // 查询默认商户
            $mer = $this->getMer($token);
            // 选择当前商户
            $mer['token'] = $token;
            $session_data = $this->chooMer($mer);
            // 如果需要，就保存token
            $this->saveToken($session_data);
            return true;
        } else {
            // 重试次
            $is_login = false;
            if ($times < 1) {
                $is_login = $this->login($times + 1);
                return $is_login;
            }
            return $is_login;
        }
    }
    // 查询默认商户
    private function getMer(string $token): array
    {
        $url = $this->payhost . $this->getuser;
        $now = $this->now;
        $post = [
            'requestTime' => date('YmdHis', $now),
            'requestId' => date('YmdHis', $now) . mt_rand(100000, 999999),
            "systemCode" => "MERDASH",
            "version" => "1.0",
            "method" => "userIdentity.queryDefaultIdentityAndMer",
            "isGuest" => true
        ];
        $header = ['host:m2.lakala.com', 'content-type:application/json', 'origin:https://customer.lakala.com', 'referer:https://customer.lakala.com/', "authorization:{$token}"];
        $res = $this->getHttpResponse($url, $header, json_encode($post));
        $data = json_decode($res, true);
        $userinfo = [];
        if ($data['code'] === '000000') {
            $userinfo = $data['data'];
        }
        return $userinfo;
    }
    // 选择当前商户
    private function chooMer(array $mer): array
    {
        $url = $this->payhost . $this->setuser;
        $now = $this->now;
        $post = [
            'requestTime' => date('YmdHis', $now),
            'requestId' => date('YmdHis', $now) . mt_rand(100000, 999999),
            "systemCode" => "MERDASH",
            "version" => "1.0",
            "method" => "userIdentity.set",
            "lamsRoleId" => "2",
            "merDataSources" => "LAMS",
            "authUserId" => "",
            "defaultMerInnerNo" => $mer['defaultMerInnerNo'],
            "defaultMerchantNo" => $mer['defaultMerchantNo']
        ];
        $header = ['host:m2.lakala.com', 'content-type:application/json', 'origin:https://customer.lakala.com', 'referer:https://customer.lakala.com/', "authorization:{$mer['token']}"];
        $res = $this->getHttpResponse($url, $header, json_encode($post));
        $data = json_decode($res, true);
        $session_data = [];
        if ($data['code'] === '000000') {
            $session_data['key'] = $data['data']['sessionKey'];
            $session_data['info'] = $data['data']['sessionInfo'];
        }
        return $session_data;
    }
    // 更新token
    private function updateToken(): bool
    {
        $is_login = $this->login();
        return $is_login;
    }

    // 获取token
    private function getToken(): array
    {
        $info = json_decode(file_get_contents($this->token_path), true);
        return $info;
    }
    // 保存token
    private function saveToken($data)
    {
        $token = $data['key'];
        $merInnerNo = $data['info']['merInnerNo'];
        $merchantNo = $data['info']['merchantNo'];
        file_put_contents($this->token_path, json_encode(['token' => $token, 'update_time' => date('Y-m-d H:i:s'), 'merInnerNo' => $merInnerNo, 'merchantNo' => $merchantNo]));
    }
    // 解析验证码
    private function getCaptchaInfo(string $image = '', string $typeid = '3'): string
    {
        $captcha = \ImgCaptcha::ttShiTu($image, $typeid);
        return $captcha;
    }
    // 请求外部资源
    private function getHttpResponse($url, $header = [], $post = null, $timeout = 10)
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_COOKIEJAR, $this->cookie_path);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $this->cookie_path);
        if ($header) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        } else {
            $httpheader[] = "Accept: */*";
            $httpheader[] = "Accept-Language: zh-CN,zh;q=0.9";
            $httpheader[] = "Connection: close";
            curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
        }
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        if ($post) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }
}
