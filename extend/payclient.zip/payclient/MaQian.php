<?php

declare(strict_types=1);

namespace payclient;

class MaQian
{
    // 收款平台
    private $pay_type = 'mqpay';
    // 收款平台账号
    private $username;
    // 平台登陆密码
    private $password;
    // token保存路径
    private $token_path;
    // Cookie保存路径
    private $cookie_path;
    // 当前时间戳
    private $now;
    // 收款平台网站
    private $payhost = 'https://ms.hkrt.cn';
    // 用户登陆接口
    private $login_path = '/merchant-server/pc/user/login';
    // 订单查询接口
    private $order_query_path = '/merchant-server/trade-record/query-range';
    // 二次验证获取Cookie接口
    private $confirm_path = '/merchant-server/pc/user/confirm';

    function __construct(array $config)
    {
        $this->username = $config['username'];
        $this->password = $config['password'];
        $this->now = time();
        // 检查token/cookie目录
        $dir_path = runtime_path() . "token/{$this->pay_type}/";
        if (!is_dir($dir_path)) {
            if (!mkdir($dir_path, 755, true)) echo '创建token/cookie目录失败';
        }
        // token/cookie文件路径
        $this->token_path = $dir_path . md5($this->username . $this->password . __CLASS__) . '.json';
        $this->cookie_path = $dir_path . md5($this->username . $this->password . __CLASS__) . '.txt';
        // 检查token文件
        if (!file_exists($this->token_path)) {
            file_put_contents($this->token_path, json_encode(['token' => 'ok', 'update_time' => date('Y-m-d H:i:s')]));
        }
    }
    // 获取订单信息
    public function getOrderInfo(array $query): array
    {
        $order_list = $this->queryOrder($query);
        $orders = [];
        if (!$order_list) return $orders;
        $payways = ['ALI' => 'alipay', 'WX' => 'wxpay'];
        foreach ($order_list as $value) {
            $order = [];
            // 平台订单流水号
            $order['order_no'] = $value['id'];
            // 支付类型
            $payway = $value['payType'];
            $order['payway'] = isset($payways[$payway]) ? $payways[$payway] : 'otherpay';
            // 收款金额
            $order['price'] = (float)$value['tradeAmount'];
            // 收款渠道(二维码编号)
            $order['channel'] = $value['sn'];
            // 添加到订单列表
            $orders[] = $order;
        }
        return $orders;
    }
    // 查询订单
    private function queryOrder(array $query, $times = 0): array
    {
        // 查询订单列表
        $url = $this->payhost . $this->order_query_path;
        $header = ['Content-Type:application/json;charset=UTF-8', 'Origin:https://devclient.hkrt.cn/', 'Referer:https://devclient.hkrt.cn/'];
        $new_query = $this->getOrderQuery($query);
        $res = $this->getHttpResponse($url . '?' . http_build_query($new_query), $header, json_encode($new_query));
        $result = json_decode($res, true);
        // 检查订单信息
        $order_list = [];
        if ($result['code'] === 10000) {
            $order_list = $result['data']['pageVo']['rows'];
        } else {
            // 重试2次
            if ($times < 1) {
                $this->updateToken();
                $order_list = $this->queryOrder($query, $times + 1);
            }
        }
        return $order_list;
    }
    // 构建订单查询数组信息
    private function getOrderQuery(array $query): array
    {
        $new_query = $query;
        $now = $this->now;
        $startTime = date('H:i:s', $now - 175);
        $startDate = date('Y-m-d', $now - 175);
        $endTime = date('H:i:s', $now);
        $endDate = date('Y-m-d', $now);
        $new_query['startTime'] = $startTime;
        $new_query['startDate'] = $startDate;
        $new_query['endTime'] = $endTime;
        $new_query['endDate'] = $endDate;
        return $new_query;
    }
    // 登陆账号
    private function login($times = 0): bool
    {
        $url = $this->payhost . $this->login_path;
        $user_info = ['mchNoOrPhone' => $this->username, 'password' => $this->password];
        $header = ['Content-Type:application/json;charset=UTF-8', 'Origin:https://devclient.hkrt.cn/', 'Referer:https://devclient.hkrt.cn/'];
        $res = $this->getHttpResponse($url, $header, json_encode($user_info));
        $data = json_decode($res, true);
        if ($data['code'] === 10000) {
            // 如何需要，就保存token
            $this->saveToken($data['data'][0]);
            // 二次验证
            $this->confirm();
            return true;
        } else {
            // 重试2次
            $is_login = false;
            if ($times < 2) {
                $is_login = $this->login($times + 1);
                return $is_login;
            }
            return $is_login;
        }
    }
    // 登陆二次验证
    private function confirm(): bool
    {
        $id = $this->getToken();
        $url = $this->payhost . $this->confirm_path . '?id=' . $id;
        $info = ['id' => $id];
        $header = ['Content-Type:application/json;charset=UTF-8', 'Origin:https://devclient.hkrt.cn/', 'Referer:https://devclient.hkrt.cn/'];
        $res = $this->getHttpResponse($url, $header, json_encode($info));
        $data = json_decode($res, true);
        $result = false;
        if ($data['code'] === 10000) $result = true;
        return $result;
    }
    // 更新token
    private function updateToken(): bool
    {
        $is_login = $this->login();
        return $is_login;
    }
    // 获取token
    private function getToken(): string
    {
        $token_info = json_decode(file_get_contents($this->token_path), true);
        return $token_info['token'];
    }
    // 保存token
    private function saveToken($data)
    {
        $token = $data['id'];
        file_put_contents($this->token_path, json_encode(['token' => $token, 'update_time' => date('Y-m-d H:i:s')]));
    }
    // 请求外部资源
    private function getHttpResponse($url, $header = [], $post = null, $timeout = 10)
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_COOKIEJAR, $this->cookie_path);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $this->cookie_path);
        if ($header) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        } else {
            $httpheader[] = "Accept: */*";
            $httpheader[] = "Accept-Language: zh-CN,zh;q=0.9";
            $httpheader[] = "Connection: close";
            curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
        }
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        if ($post) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }
}
