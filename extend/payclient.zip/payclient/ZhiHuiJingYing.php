<?php

declare(strict_types=1);

namespace payclient;

class ZhiHuiJingYing
{
    // 收款平台
    private $pay_type = 'storepay';
    // 收款平台账号
    private $username;
    // 平台登陆密码
    private $password;
    // token保存路径
    private $token_path;
    // Cookie保存路径
    private $cookie_path;
    // 当前时间戳
    private $now;
    // 收款平台网站
    private $payhost = 'https://store.zhihuijingyingba.com';
    // 用户登陆接口
    private $login_path = '/zhihuijingying/sys/login';
    // 订单查询接口
    private $order_query_path = '/zhihuijingying/orderorder/wxcOrderOrder/list';
    // 验证码接口
    private $captcha_path = '/zhihuijingying/sys/randomImage/';

    function __construct(array $config)
    {
        $this->username = $config['username'];
        $this->password = $config['password'];
        $this->now = time();
        // 检查token/cookie目录
        $dir_path = runtime_path() . "token/{$this->pay_type}/";
        if (!is_dir($dir_path)) {
            if (!mkdir($dir_path, 755, true)) echo '创建token/cookie目录失败';
        }
        // token/cookie文件路径
        $this->token_path = $dir_path . md5($this->username . $this->password . __CLASS__) . '.json';
        $this->cookie_path = $dir_path . md5($this->username . $this->password . __CLASS__) . '.txt';
        // 检查token文件
        if (!file_exists($this->token_path)) {
            file_put_contents($this->token_path, json_encode(['token' => 'ok', 'update_time' => date('Y-m-d H:i:s')]));
        }
    }
    // 获取订单信息
    public function getOrderInfo(array $query): array
    {
        $order_list = $this->queryOrder($query);
        $orders = [];
        if (!$order_list) return $orders;
        $payways = [2 => 'alipay', 1 => 'wxpay'];
        foreach ($order_list as $value) {
            $order = [];
            // 平台订单流水号
            $order['order_no'] = $value['id'];
            // 支付类型
            $payway = $value['payWay'];
            $order['payway'] = isset($payways[$payway]) ? $payways[$payway] : 'otherpay';
            // 收款金额
            $order['price'] = (float)$value['totalPrice'];
            // 收款渠道(二维码编号)
            $order['channel'] = $value['merchantId'];
            // 添加到订单列表
            $orders[] = $order;
        }
        return $orders;
    }
    // 查询订单
    private function queryOrder(array $query, $times = 0): array
    {
        // 查询订单列表
        $url = $this->payhost . $this->order_query_path;
        $token = $this->getToken();
        $header = ['Host:store.zhihuijingyingba.com', 'Referer:https://store.zhihuijingyingba.com/jingying/orderorder/WxcOrderOrderList', "X-Access-Token:{$token}"];
        $new_query = $this->getOrderQuery($query);
        $res = $this->getHttpResponse($url . '?' . http_build_query($new_query), $header);
        $result = json_decode($res, true);
        // 检查订单信息
        $order_list = [];
        if (isset($result['code']) && $result['code'] === 200) {
            $order_list = $result['result']['records'];
        } else {
            // 重试1次
            if ($times < 1) {
                $this->updateToken();
                $order_list = $this->queryOrder($query, $times + 1);
            }
        }
        return $order_list;
    }
    // 构建订单查询数组信息
    private function getOrderQuery(array $query): array
    {
        $new_query = $query;
        $now = $this->now;
        $startTime = date('Y-m-d H:i:s', $now - 175);
        $endTime = date('Y-m-d H:i:s', $now);
        $new_query['createTime_begin'] = $startTime;
        $new_query['createTime_end'] = $endTime;
        $new_query['_t'] = $now;
        return $new_query;
    }
    // 获取验证码图像
    private function getCaptcha(): array
    {
        $timestamp = $this->now . mt_rand(100, 999);
        $url = $this->payhost . $this->captcha_path . "{$timestamp}?_t={$this->now}";
        $header = ['Host:store.zhihuijingyingba.com', 'Referer:http://store.zhihuijingyingba.com/user/login?redirect=%2F'];
        $res = $this->getHttpResponse($url, $header);
        $data = json_decode($res, true);
        $captcha_info = [];
        if ($data['code'] === 0) {
            $captcha_info['message'] = $data['message'];
            $captcha_info['timestamp'] = $timestamp;
        }
        return $captcha_info;
    }
    // 登陆账号
    private function login($times = 0): bool
    {
        $captcha_info = $this->getCaptcha();
        $url = $this->payhost . $this->login_path;
        $user_info = [
            "username" => $this->username,
            "password" => $this->password,
            "remember_me" => true,
            "captcha" => $captcha_info['message'],
            "checkKey" => $captcha_info['timestamp'],
        ];
        $header = ['Content-Type:application/json;charset=UTF-8', 'Host:store.zhihuijingyingba.com', 'Origin:http://store.zhihuijingyingba.com', 'Referer:http://store.zhihuijingyingba.com/user/login?redirect=%2F'];
        $res = $this->getHttpResponse($url, $header, json_encode($user_info));
        $data = json_decode($res, true);
        if (isset($data['code']) && $data['code'] === 200) {
            // 如何需要，就保存token
            $this->saveToken($data['result']);
            return true;
        } else {
            // 重试2次
            $is_login = false;
            if ($times < 2) {
                $is_login = $this->login($times + 1);
                return $is_login;
            }
            return $is_login;
        }
    }
    // 更新token
    private function updateToken(): bool
    {
        $is_login = $this->login();
        return $is_login;
    }
    // 获取token
    private function getToken(): string
    {
        $token_info = json_decode(file_get_contents($this->token_path), true);
        return $token_info['token'];
    }
    // 保存token
    private function saveToken(array $data)
    {
        $token = $data['token'];
        file_put_contents($this->token_path, json_encode(['token' => $token, 'update_time' => date('Y-m-d H:i:s')]));
    }
    // 请求外部资源
    private function getHttpResponse($url, $header = [], $post = null, $timeout = 10)
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_COOKIEJAR, $this->cookie_path);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $this->cookie_path);
        if ($header) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        } else {
            $httpheader[] = "Accept: */*";
            $httpheader[] = "Accept-Language: zh-CN,zh;q=0.9";
            $httpheader[] = "Connection: close";
            curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
        }
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        if ($post) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }
}
