<?php
//000000000000
 exit();?>
a:9:{s:2:"id";s:3:"int";s:8:"platform";s:6:"string";s:4:"name";s:6:"string";s:10:"class_name";s:6:"string";s:5:"query";s:6:"string";s:5:"state";s:3:"int";s:11:"create_time";s:9:"timestamp";s:3:"_pk";s:2:"id";s:8:"_autoinc";s:2:"id";}