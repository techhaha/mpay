<?php
//000000000000
 exit();?>
a:12:{s:2:"id";s:3:"int";s:3:"pid";s:3:"int";s:10:"secret_key";s:6:"string";s:8:"nickname";s:6:"string";s:8:"username";s:6:"string";s:8:"password";s:6:"string";s:5:"state";s:3:"int";s:4:"role";s:3:"int";s:11:"create_time";s:9:"timestamp";s:11:"delete_time";s:9:"timestamp";s:3:"_pk";s:2:"id";s:8:"_autoinc";s:2:"id";}