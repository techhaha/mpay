<?php
//000000000000
 exit();?>
a:9:{s:2:"id";s:3:"int";s:10:"account_id";s:3:"int";s:7:"channel";s:6:"string";s:6:"qrcode";s:6:"string";s:9:"last_time";s:9:"timestamp";s:5:"state";s:3:"int";s:11:"delete_time";s:9:"timestamp";s:3:"_pk";s:2:"id";s:8:"_autoinc";s:2:"id";}