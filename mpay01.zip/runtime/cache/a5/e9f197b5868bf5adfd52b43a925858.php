<?php
//000000000000
 exit();?>
a:10:{s:2:"id";s:3:"int";s:3:"pid";s:3:"int";s:8:"platform";s:6:"string";s:7:"account";s:6:"string";s:8:"password";s:6:"string";s:5:"state";s:3:"int";s:7:"pattern";s:3:"int";s:11:"delete_time";s:9:"timestamp";s:3:"_pk";s:2:"id";s:8:"_autoinc";s:2:"id";}